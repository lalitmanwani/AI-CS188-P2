# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions, Actions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """




    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def nf(self,currentGameState,successorGameState):
        x = currentGameState.getNumFood()
        y = successorGameState.getNumFood()
        return x,y

    def minim(self,mndst,distance):
        return min(mndst, distance)

    def ispcded(currentGameState):
        if currentGameState:
            return True


    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"

        ghstPost = successorGameState.getGhostPositions()


        for ghostPost in ghstPost:
            if ghostPost: 
                if manhattanDistance(newPos, ghostPost) > 2:
                    pass
                elif manhattanDistance(newPos, ghostPost) < 2: 
                    return -float('inf')
                else:
                    pass
            else:
                break        

        nf,nnf = self.nf(currentGameState,successorGameState)


        if ispcded(currentGameState): 
            if nnf > nf:
                pass
            elif nnf < nf:
                return float('inf')
            else:
                pass                


        mndst = float('inf')


        for food in newFood.asList():
            if not food:
                pass
            else:    
                dst = manhattanDistance(newPos, food)
                
        return 1.0 / self.minim(mndst, dst) 

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

    def isTerminalState(self, gameState):
        return gameState.isWin() or gameState.isLose()

    def isPacman(self, agent):
        return agent == 0

class AlphaBetaAgent(MultiAgentSearchAgent):

    def calcagent(self,gameState):
        if gameState:
            gs = gameState.getNumAgents()
        return gs


    def succ(self,gameState,agent,action):
        if not gameState:
            pass
        else:
            return gameState.generateSuccessor(agent, action)

    def ispcded(currentGameState):
        if not currentGameState:
            return False
        else: return True


    def chck(self,depth,bstval,v,action):       
        if depth == 1:
            if bstval == v:
                self.action = action
            else:
                pass
        else:
            pass

    def maxim(self,bstval,v):
            return max(bstval, v)





    def alphabeta(self, gameState, agent=0, depth=0,alpha=float("-inf"), beta=float("inf")):

        gs = self.calcagent(gameState)

        agent = agent % gs

        if not self.isTerminalState(gameState):
            pass
        elif self.isTerminalState(gameState):
            if ispcded(gameState):
                return self.evaluationFunction(gameState)
        else:
            pass    

        if not self.isPacman(agent):
            bstval = float("inf")
            for action in gameState.getLegalActions(agent):
                if not action:
                    pass
                elif action:
                    if ispcded(gameState):
                        successor = self.succ(gameState,agent,action)
                        v = self.alphabeta(successor, agent + 1, depth, alpha, beta)
                        bstval = min(bstval, v)

                        if bstval > alpha:
                            pass
                        elif bstval < alpha:

                            return bstval
                        else:
                            pass
                        beta = min(beta, bstval)
            return bstval




        elif self.isPacman(agent):

            if depth < self.depth:
       
                depth = depth + 1

                bstval = float("-inf")
                for action in gameState.getLegalActions(agent):
                    if not action:
                        pass
                    else:
                        successor = self.succ(gameState,agent, action)
                        v = self.alphabeta(successor, agent + 1, depth, alpha, beta)
                        bstval = self.maxim(bstval,v)

                        if ispcded(gameState):

                            self.chck(depth,bstval,v,action) 

                            if bstval < beta: 
                                pass
                            elif bstval > beta:        
                                return bstval
                            else:
                                pass

                            alpha = self.maxim(alpha, bstval)
                return bstval



            else:
                return self.evaluationFunction(gameState)







    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        self.alphabeta(gameState)
        return self.action



class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """


    def calcagent(self,gameState):
        if gameState:
            gs = gameState.getNumAgents()
        return gs

    def term(self,gameState):
        if gameState:
            if not self.isTerminalState(gameState):
                pass
            elif self.isTerminalState(gameState):
                return True
            else:
                pass



    def succ(self,gameState,agent,action):
        if not gameState:
            pass
        else:
            return gameState.generateSuccessor(agent, action)


    def ispcded(gameState):
        if gameState:
            return True




    def chck(self,bstval,depth,action,v):
        if depth == 1:
            if bstval != v: 
                pass
            elif bstval == v:
                self.action = action 
            else:
                pass 
        else:
            pass  


    def minimax(self, gameState, agent=0, depth=0):



      
        agent = agent % self.calcagent(gameState)

        termin = self.term(gameState)    

        if not termin:
            pass
        else:
            return self.evaluationFunction(gameState)

            

        if not self.isPacman(agent):

            bstval = float("inf")
            for action in gameState.getLegalActions(agent):
                if not action:               
                    pass
                else: 
                    if ispcded(gameState):
                        successor = self.succ(gameState,agent, action)
                        v = self.minimax(successor, agent+1, depth)
                        bstval = min(bstval, v)
            return bstval

        else:
            if depth < self.depth:
                depth = depth+1
                bstval = float("-inf")
                for action in gameState.getLegalActions(agent):
                    if not action:
                        pass
                    else:
                        if ispcded(gameState):
                            successor = self.succ(gameState,agent, action)
                            v = self.minimax(successor, agent+1, depth)
                            bstval = max(bstval, v)
                            self.chck(bstval,depth,action,v) 

                return bstval
            else:
                return self.evaluationFunction(gameState)
















    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getlglact(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game

          gameState.isWin():
            Returns whether or not the game state is a winning state

          gameState.isLose():
            Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"
        # This function returns the best action's utility, but we can
        # ignore that value as we are interested in the action, not the value
        self.minimax(gameState)
        return self.action




class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def calcagent(self,gameState):
        if gameState:
            gs = gameState.getNumAgents()
        return gs


    def term(self,gameState):
        if gameState:
            if not self.isTerminalState(gameState):
                pass
            elif self.isTerminalState(gameState):
                return True
            else:
                pass


    def chck(self,depth,bstval,v,action):
        if depth == 1: 
            if bstval != v:
                pass
            elif bstval == v:
                self.action = action
            else:
                pass


    def succ(self,gameState,agent,action):
        if not gameState:
            pass
        else:
            return gameState.generateSuccessor(agent, action)

    def ispcded(currentGameState):
        if not currentGameState:
            return False
        else: return True


    def maxim(self,bstval,v):
            return max(bstval, v)


    def length(self,lglact):
        if lglact:
            return len(lglact)

    def p(self,gameState,agent,action,lglact):
        o = self.succ(gameState,agent, action)
        t = 1.0 / self.length(lglact)
        return o,t





    def expectimax(self, gameState, agent=0, depth=0):


        agent = agent % self.calcagent(gameState)


        termin = self.term(gameState)    

        if not termin:
            pass
        else:
            return self.evaluationFunction(gameState)

            


        if  self.isPacman(agent):
            if depth >= self.depth:

                return self.evaluationFunction(gameState)
            elif depth < self.depth:
                if ispcded(gameState):
                    depth = depth + 1 
                    bstval = float("-inf")
                    for act in gameState.getLegalActions(agent):
                        if not act:
                            pass
                        elif act:
                            successor = self.succ(gameState,agent, act)
                            v = self.expectimax(successor, agent+1, depth)
                            if ispcded(gameState):
                                bstval = self.maxim(bstval,v)
                                self.chck(depth,bstval,v,act)
                    return bstval


        else:

                lglact = gameState.getLegalActions(agent)
                v = 0
                for act in lglact:
                    if act:
                        if ispcded(gameState):
                            successor,p = self.p(gameState,agent,act,lglact)
                            v += p * self.expectimax(successor, agent+1, depth)
                    elif not act:
                        pass        
                return v


    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        self.expectimax(gameState)
        return self.action







def betterEvaluationFunction(currentGameState):
    
    "*** YOUR CODE HERE ***"
    

    ghostStates = ghstST(currentGameState)

    pcpos = pacps(currentGameState)


    fd = currentGameState.getFood()

    a = ispcded(currentGameState)

    cstfooddist = clstFdDist(fd,pcpos)



    if a:
        # evaluate the current state of the ghosts
        nstgstdist = float("inf")
        gstevl = 0
        for ghost in ghostStates:
            if ghost:          
                ghostPosition = ghost.getPosition()
                md = manhattanDistance(pcpos, ghostPosition)
                if ghost.scaredTimer < md:
                    pass
                elif ghost.scaredTimer == 0:

                    if md > nstgstdist:
                        pass    
                    elif md < nstgstdist:
                        nstgstdist = md
                    else:
                        pass

                elif ghost.scaredTimer > md:
                    gstevl += 200 - md

                else:
                    pass

    if nstgstdist == float("inf"):
        nstgstdist = 0
    gstevl += nstgstdist



    return comptgamescr(currentGameState,gstevl,cstfooddist)



    capdist = capsdist(capdist)


    return comptcapsuledst(capdist)
    





def pacps(currentGameState):
    if currentGameState.getPacmanPosition():
        return currentGameState.getPacmanPosition()
    else:
        return None
    


def ghstST(currentGameState):

    if currentGameState.getGhostStates():
        return currentGameState.getGhostStates()
    else:
        return None


def clstFdDist(food,pcpos):
    
    if food:

        foodsPos = food.asList()
        foodsPos = sorted(foodsPos, key = lambda pos: manhattanDistance(pcpos, pos))
        cstfooddist = 0
        if len(foodsPos) < 0:
            pass
        elif len(foodsPos) > 0:    
            cstfooddist = manhattanDistance(foodsPos[0], pcpos)
        else:
            pass
    return cstfooddist



def capsdist(capdist):
    if capdist is None:
        capdist = 0.0
    else:
        capdist = 1.0 / capdist
    return capdist

def ispcded(currentGameState):
    if currentGameState:
        return True


def comptgamescr(currentGameState,gstevl,cstfooddist):
    currentGameScore = currentGameState.getScore()
    x = len(currentGameState.getCapsules())
    fc = currentGameState.getNumFood()

    if currentGameState:  
        a5 = 2*cstfooddist
        a4 = 2 * x
        A  = a4 -a5

        a3 = 1 * gstevl

    return currentGameScore - 10 * fc + a3 +  A
    


def comptcapsuledst(capdist):

    if capdist:
        a3 = 0.5*capdist
        a2 = 5.0*score 

    return 10.0*foodDistance + a2 + a3     



# Abbreviation
better = betterEvaluationFunction


